<div class="footer">
    <div class="wrapper">
        <p class="text-center text-black">2022 all rights reseved ,admin panel develoved By <a href="#"
                class="cn">MedBD</a></p>
    </div>
</div>
</body>

</html>